export { hashPassword, comparePassword } from "@dakshsaini2/backend-core";
